import requests
from bs4 import BeautifulSoup
import ssl
from itertools import count
import pandas as pd
import time
import csv
from selenium import webdriver
#from  geopy.geocoders import Nominatim
import geocoder #pip install
import openpyxl #pip install
context = ssl._create_unverified_context()
url = "https://kr.hotels.com/search.do?resolved-location=CITY%3A759818%3AUNKNOWN%3AUNKNOWN&destination-id=759818&q-destination=%EC%84%9C%EC%9A%B8,%20%ED%95%9C%EA%B5%AD&q-check-in=2020-05-18&q-check-out=2020-05-19&q-rooms=1&q-room-0-adults=2&q-room-0-children=0"

driver = webdriver.Chrome(('chromedriver'))
driver.get(url)
driver.implicitly_wait(5)

brand_list = []
SCROLL_PAUSE_TIME=2
last_height = driver.execute_script("return document.body.scrollHeight")
a=0
while True:
    a +=1
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight);")
    time.sleep(SCROLL_PAUSE_TIME)
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight-50);")
    time.sleep(SCROLL_PAUSE_TIME)
    new_height = driver.execute_script("return document.body.scrollHeight")
    if new_height == last_height:
        break
    last_height = new_height
    if a==1:
        break
a = 0
html = driver.page_source
soup = BeautifulSoup(html,'html.parser')

            
result = []

#name = soup.select('#listings > ol > li > article > section > div > h3 > a')
address = soup.select('#listings > ol > li > article > section > div > address > span')

    
for i in address:
    result.append(i.text.split(','))



data = pd.DataFrame(result)



data.to_excel('hotel2.xlsx',index=False)#,encoding="euc-kr"

filename = 'hotel2.xlsx'
exelFile = openpyxl.load_workbook(filename)
ws = exelFile.active
ws.delete_rows(1)
ws.delete_cols(2)
ws.delete_cols(3)
ws.delete_cols(4)
ws.delete_cols(5)

sheet = exelFile.worksheets[0]


rowCount=1

for row in sheet.rows:
    
    g = geocoder.google(row[0].value,key='AIzaSyAN4xkazpOSE9TySygW7SBgLLOIOU2LYQw')
    lat_cell = sheet.cell(row = rowCount, column = 2)
    lng_cell = sheet.cell(row = rowCount, column = 3)
    
    geo = g.latlng
    
    lat_cell.value = geo[0]
    lng_cell.value = geo[1]
    rowCount = rowCount + 1

exelFile.save("hotel3.xlsx")

    
    

