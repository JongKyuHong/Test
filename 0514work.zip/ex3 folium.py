import folium

loc = folium.Map(location=[37.531079, 126.983528],zoom_start=100)
loc
