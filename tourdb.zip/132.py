import requests
from bs4 import BeautifulSoup
import ssl
from itertools import count
import pandas as pd
import time
import csv
from selenium import webdriver

driver = webdriver.Chrome('chromedriver')
driver.implicitly_wait(3)
url = "https://www.booking.com/searchresults.ko.html?aid=309654&label=hotels-korean-ko-B7c5TdtjyzgvSD4R*yebXwS95119518172%3Apl%3Ata%3Ap1%3Ap22%2C562%2C000%3Aac%3Aap%3Aneg%3Afi%3Atikwd-319736586%3Alp1009871%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YcsZ-Id2vkzIfTmYhvC5HOg&sid=2033247645ffca94e10b816ddad43194&sb=1&sb_lp=1&src=index&src_elem=sb&error_url=https%3A%2F%2Fwww.booking.com%2Findex.ko.html%3Faid%3D309654%3Blabel%3Dhotels-korean-ko-B7c5TdtjyzgvSD4R%252AyebXwS95119518172%253Apl%253Ata%253Ap1%253Ap22%252C562%252C000%253Aac%253Aap%253Aneg%253Afi%253Atikwd-319736586%253Alp1009871%253Ali%253Adec%253Adm%253Appccp%253DUmFuZG9tSVYkc2RlIyh9YcsZ-Id2vkzIfTmYhvC5HOg%3Bsid%3D2033247645ffca94e10b816ddad43194%3Bsb_price_type%3Dtotal%26%3B&ss=%EC%84%9C%EC%9A%B8&is_ski_area=0&ssne=%EC%84%9C%EC%9A%B8&ssne_untouched=%EC%84%9C%EC%9A%B8&dest_id=-716583&dest_type=city&checkin_year=2020&checkin_month=5&checkin_monthday=18&checkout_year=2020&checkout_month=5&checkout_monthday=19&group_adults=2&group_children=0&no_rooms=1&b_h4u_keep_filters=&from_sf=1"
driver.get(url)

#name = driver.find_elements_by_css_selector('#hotellist_inner > div > div.sr_item_content.sr_item_content_slider_wrapper > div.sr_property_block_main_row > div.sr_item_main_block > div.sr-hotel__title-wrap > h3 > a > span.sr-hotel__name')


html = driver.page_source
soup = BeautifulSoup(html,'html.parser')
name = soup.select('#hotellist_inner > div > div.sr_item_content.sr_item_content_slider_wrapper > div.sr_property_block_main_row > div.sr_item_main_block > div.sr-hotel__title-wrap > h3 > a > span.sr-hotel__name')
#print(name)
for n in name:
    print(n.text.strip())
