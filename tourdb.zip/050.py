import requests
from bs4 import BeautifulSoup
 
headers = {"accept-agent":"Mozilla/5.0 (iPad; CPU OS 11_0 like Mac OS X) AppleWebKit/604.1.34 (KHTML, like Gecko)\
    Version/11.0 Mobile/15A5341f Safari/604.1"}
base_url = "http://maps.googleapis.com/maps/api/geocode/xml?address="
url = base_url+"천안시"
resp = requests.get(url, headers=headers)
html = BeautifulSoup(resp.text, "lxml")
lat = html.select("location > lat")
lng = html.select("location > lng")
print(lat[0].get_text())
print(lng[0].get_text())
