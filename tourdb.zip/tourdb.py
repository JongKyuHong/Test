from selenium import webdriver
from bs4 import BeautifulSoup

from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC 
import time 

from TourDBManager import DBHelper as DB
db = DB() 

result =[]
url= "http://tour.interpark.com/"
driver = webdriver.Chrome('chromedriver.exe')
driver.get(url)
driver.find_element_by_id('SearchGNBText').send_keys('하와이')
driver.find_element_by_class_name('search-btn').click()
try:
    WebDriverWait(driver,10).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'moreBtn'))
    )
except Exception as e:
    print("오류발생",e)

driver.find_element_by_css_selector(
    '.oTravelBox>.boxList>.moreBtnWrap>.moreBtn').click()
time.sleep(1)
for page in range(1,10):
    try:
        driver.execute_script("searchModule.SetCategoryList(%s, '')"%str(page))
        time.sleep(2)
        boxItems = driver.find_elements_by_css_selector(
            '.panelZone>.recommService ~.oTravelBox>.boxList>li')
        print("*"*10 + str(page)+"*"*10)
        for ele in boxItems:
            print('상품명: ' + ele.find_element_by_css_selector('h5.proTit').text)
            print("가격 : "+ele.find_element_by_css_selector('strong.proPrice').text )
            for info in ele.find_elements_by_css_selector(
                '.info-row .proInfo'):
                print(info.text)
            
            title = ele.find_element_by_css_selector('h5.proTit').text
            price = ele.find_element_by_css_selector('strong.proPrice').text
            print(price[:-3])
            link = ele.find_element_by_css_selector(
                'a').get_attribute('onclick')
            link = link.split(',')
            link = link[0].replace('searchModule.OnClickDetail(','')
            link = link[1:-1]
            print(link)
            result.append([title]+[price]+['미주']+[link]+['하와이'])
    except Exception as e:
        print("오류", e)
    
for ele in result:
    db.db_insertTour(
        ele[0],
        ele[1],
        ele[2],
        ele[3],
        ele[4]
    )
print("DB 저장완료")
driver.close()
