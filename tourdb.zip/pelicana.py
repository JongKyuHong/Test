import urllib.request
from bs4 import BeautifulSoup
import ssl
from itertools import count
context = ssl._create_unverified_context()
for page in count():
    url = "https://pelicana.co.kr/store/stroe_search.html?page=%s&branch_name=&gu=&si=" %str(page)
    # % urllib.parse.quote("서울특별시") 
    print(url)
    request = urllib.request.Request(url)
    reponse = urllib.request.urlopen(request, context=context)
    soupdata = BeautifulSoup(reponse, "html.parser")

    #class="table mt20"
    store_table = soupdata.find('table',{'class':'table mt20'})
    tbody = store_table.find("tbody")
    tr = tbody.findAll('tr')
    bEnd = True
    for store in tr:
        bEnd = False
        store_info= list(store.strings)
        store_name = store_info[1]
        store_address = store_info[3]
        store_phone = store_info[5].strip()
        print(store_name, store_address, store_phone)
    if(bEnd == True):
        break