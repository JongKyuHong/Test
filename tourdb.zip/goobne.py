import urllib.request
from bs4 import BeautifulSoup
from selenium import webdriver
from itertools import count
import ssl 
import time
url = "https://www.goobne.co.kr/store/search_store.jsp"
#context = ssl._create_unverified_context()
#req = urllib.request.Request(url)
#response = urllib.request.urlopen(req, context=context)
#response.read().decode('utf-8')

driver = webdriver.Chrome("chromedriver.exe")
driver.get(url)
time.sleep(4)
result = []
for page in count():
    driver.execute_script("store.getList('%s')" % str(page+1))
    time.sleep(2)
    html = driver.page_source
    soupData = BeautifulSoup(html, "html.parser")
    stores = soupData.find_all('tbody',{'id':'store_list'})
    
    print("*"*10+str(page+1)+"*"*10)
    if(page > 3):
        break
    for store_list in stores:
        for store_tr in store_list:             
            store = list(store_tr.strings)
            if(store[0] == ""):
                break
            
            if( store[3] == ''):
                store_address = store[5]
            else:
                store_address = store[6]
            store_name = store[1]            
            store_phone = store[3]
            
           # store_sido = store_address.split()[:] 
           # store_gu = store_address.split()[0]                  
            print(store[1],store[3],store[6])
            result.append([store_name]+[store_address]+[store_phone])
        
#########################################################3

print("*"*50)
print("total stores:" + str(len(result)))
import pandas as pd 
pf = pd.DataFrame(result)
pf.to_csv('goobne.csv', encoding="euc-kr")
print("*"*50)
print("저장 완료 !!!!")